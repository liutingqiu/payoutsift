# PayoutSift demo

This demo contains fictional CSV inputs and the complete report packet generated from them. Open `demo-output/report.html` in a current browser. The red review states are intentional so you can inspect duplicate, orphan, difference, ambiguity, and missing-source handling.

The demo is for evaluation only and is not licensed for live business reconciliation. The paid download includes the local Python tool, templates, tests, documentation, a single-business commercial license, and 30 days of setup and reproducible defect support.
